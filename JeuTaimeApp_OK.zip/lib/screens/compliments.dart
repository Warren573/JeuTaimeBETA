import 'package:flutter/material.dart';

class ComplimentsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("Bienvenue sur l'ecran compliments")),
    );
  }
}