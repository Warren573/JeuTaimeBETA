import 'package:flutter/material.dart';

class DefisScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("Bienvenue sur l'ecran defis")),
    );
  }
}