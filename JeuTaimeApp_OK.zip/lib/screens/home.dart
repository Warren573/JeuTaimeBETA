import 'package:flutter/material.dart';
import 'profils.dart';
import 'bars.dart';
import 'defis.dart';
import 'compliments.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    Center(child: Text("Bienvenue sur l'ecran d'accueil")),
    ProfilsScreen(),
    BarsScreen(),
    DefisScreen(),
    ComplimentsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('JeuTaime'),
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.pink,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Accueil'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profils'),
          BottomNavigationBarItem(icon: Icon(Icons.local_bar), label: 'Bars'),
          BottomNavigationBarItem(icon: Icon(Icons.videogame_asset), label: 'Defis'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Compliments'),
        ],
      ),
    );
  }
}