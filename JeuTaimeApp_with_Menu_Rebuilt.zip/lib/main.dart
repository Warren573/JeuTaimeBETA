import 'package:flutter/material.dart';
import 'screens/home.dart';
import 'screens/profils.dart';
import 'screens/bars.dart';
import 'screens/defis.dart';
import 'screens/compliments.dart';

void main() {
  runApp(JeuTaimeApp());
}

class JeuTaimeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JeuTaime',
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
      home: HomeScreen(),
    );
  }
}
