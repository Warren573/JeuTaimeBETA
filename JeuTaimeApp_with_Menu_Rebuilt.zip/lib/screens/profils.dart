import 'package:flutter/material.dart';

class ProfilsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Profils')),
      body: Center(child: Text('Bienvenue sur l'écran profils')),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Accueil'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Profils'),
          BottomNavigationBarItem(icon: Icon(Icons.local_bar), label: 'Bars'),
          BottomNavigationBarItem(icon: Icon(Icons.flag), label: 'Défis'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Compliments'),
        ],
        onTap: (index) {
          switch (index) {
            case 0: Navigator.push(context, MaterialPageRoute(builder: (_) => AccueilScreen())); break;
            case 1: Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilsScreen())); break;
            case 2: Navigator.push(context, MaterialPageRoute(builder: (_) => BarsScreen())); break;
            case 3: Navigator.push(context, MaterialPageRoute(builder: (_) => DefisScreen())); break;
            case 4: Navigator.push(context, MaterialPageRoute(builder: (_) => ComplimentsScreen())); break;
          }
        },
      ),
    );
  }
}

// Importations pour navigation croisée
import 'home.dart';
import 'profils.dart';
import 'bars.dart';
import 'defis.dart';
import 'compliments.dart';
