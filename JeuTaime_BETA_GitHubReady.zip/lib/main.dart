
import 'package:flutter/material.dart';

void main() {
  runApp(JeuTaimeApp());
}

class JeuTaimeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JeuTaime',
      home: Scaffold(
        appBar: AppBar(title: Text('Bienvenue sur JeuTaime')),
        body: Center(child: Text('Page d'accueil')),
      ),
    );
  }
}
